inject [![Build Status](https://secure.travis-ci.org/facebookgo/inject.png)](https://travis-ci.org/facebookgo/inject)
======

Documentation: https://godoc.org/github.com/facebookgo/inject
