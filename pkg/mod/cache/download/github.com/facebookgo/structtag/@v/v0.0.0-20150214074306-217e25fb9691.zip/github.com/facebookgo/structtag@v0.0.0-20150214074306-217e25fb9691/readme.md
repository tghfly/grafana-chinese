structtag [![Build Status](https://secure.travis-ci.org/facebookgo/structtag.png)](https://travis-ci.org/facebookgo/structtag)
=========

This is taken from the Go standard library but modified to return a boolean
indicating if a struct tag was found or not to allow differentiating an empty
struct tag from a non existing struct tag.

License: http://golang.org/LICENSE

Documentation: https://godoc.org/github.com/facebookgo/structtag
